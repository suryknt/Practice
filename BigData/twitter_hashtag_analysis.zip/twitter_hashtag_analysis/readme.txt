Steps to Run:
- Set up python environment
- Download and install required modules
- Register @ dev.twitter.com to generate Secret key and access token
- Modify twitter_feed_to_socket.py with secret key and access token and run 
- Modify query string (optional)
- Run spark_stream_client.py