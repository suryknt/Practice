=======
History
=======

0.1.0 (2017-12-19)
------------------

* First release on PyPI.
