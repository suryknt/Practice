=======================
Recomendation Engine V1
=======================


.. image:: https://img.shields.io/pypi/v/recomendation_engine_v1.svg
        :target: https://pypi.python.org/pypi/recomendation_engine_v1

.. image:: https://img.shields.io/travis/suryknt/recomendation_engine_v1.svg
        :target: https://travis-ci.org/suryknt/recomendation_engine_v1

.. image:: https://readthedocs.org/projects/recomendation-engine-v1/badge/?version=latest
        :target: https://recomendation-engine-v1.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status

.. image:: https://pyup.io/repos/github/suryknt/recomendation_engine_v1/shield.svg
     :target: https://pyup.io/repos/github/suryknt/recomendation_engine_v1/
     :alt: Updates


This is the first version of the generic recommendation engine for retail applications


* Free software: Apache Software License 2.0
* Documentation: https://recomendation-engine-v1.readthedocs.io.


Features
--------

* TODO

Credits
---------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage

