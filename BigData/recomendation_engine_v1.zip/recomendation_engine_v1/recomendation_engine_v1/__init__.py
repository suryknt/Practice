# -*- coding: utf-8 -*-

"""Top-level package for Recomendation Engine V1."""

__author__ = """Suryakant Bhimraj Singh"""
__email__ = 'suryknt@gmail.com'
__version__ = '0.1.0'

