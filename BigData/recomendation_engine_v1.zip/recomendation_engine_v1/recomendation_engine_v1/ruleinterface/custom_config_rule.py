
class CustomRule:
    def __init__(self):
        pass

    def applyRule(self):
        pass
