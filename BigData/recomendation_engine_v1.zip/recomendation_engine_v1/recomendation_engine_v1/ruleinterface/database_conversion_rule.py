

class DatabaseConversion:
    def __init__(self):
        pass

    def applyRule(self):
        pass

    def streamData(self):
        pass

    def readData(self):
        pass
