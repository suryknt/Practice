
class DataTrainMapping:
    def __init__(self):
        pass

    def applyRule(self,rule):
        pass

    def mapFeatureData(self,config):
        pass

    def mapLabelData(self,config):
        pass

