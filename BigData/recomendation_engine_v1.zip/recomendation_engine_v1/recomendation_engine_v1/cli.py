# -*- coding: utf-8 -*-
"""Console script for recomendation_engine_v1."""

import click


@click.command()
def main(args=None):
    """Console script for recomendation_engine_v1."""

if __name__ == "__main__":
    main()
