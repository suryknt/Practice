from ..interfaces.rule_interface import RuleInterface

class CustomRule(RuleInterface):
    def __init__(self):
        pass

    def applyRule(self):
        pass
