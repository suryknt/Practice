from ..interfaces.rule_interface import RuleInterface

class DataRefinement(RuleInterface):

    def __init__(self):
        pass

    def applyRule(self,rule):
        pass

    def exploreData(self):
        pass

    def facetBy(self):
        pass

    def sortBy(self):
        pass

    def segmentData(self):
        pass

    def editData(self):
        pass

    def editColumn(self):
        pass

    def removeValue(self):
        pass

