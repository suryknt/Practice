=====
Usage
=====

To use Recomendation Engine V1 in a project::

    import recomendation_engine_v1
